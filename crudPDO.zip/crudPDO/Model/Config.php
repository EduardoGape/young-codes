<?php
    //Dados pessoais podem variar - como padrão o xammp usa esse aceeso abaixo
    $username = 'root';
    $password = '';
    try {
        //Crie um Banco de dados mysql 
        $conn = new PDO('mysql:host=localhost;dbname=meuBancoDeDados', $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
    }
    //referencia - https://www.devmedia.com.br/php-pdo-como-se-conectar-ao-banco-de-dados/37211
?>