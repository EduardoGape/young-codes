<?php
    include_once '../Model/Config.php';

    //Codigo da aula passada
    // try {
    //     //para fazer uma requisição no banco esta tabela deve ser criada
    //     $stmt = $conn->prepare('INSERT INTO minhaTabela (email) VALUES(:email)');
    //     $stmt->execute(array(
    //       ':email' => $email
    //     ));
    // } catch(PDOException $e) {
    //     echo 'Error: ' . $e->getMessage();
    // }

    if (isset($_REQUEST["act"]) && $_REQUEST["act"] == "save" && $email != "") {
        try {
            $stmt = $conn->prepare("INSERT INTO minhaTabela (email) VALUES (?)");
            $stmt->bindParam(1, $email);
             
            if ($stmt->execute()) {
                if ($stmt->rowCount() > 0) {
                    echo "Dados cadastrados com sucesso!";
                    $email = null;
                } else {
                    echo "Erro ao tentar efetivar cadastro";
                }
            } else {
                   throw new PDOException("Erro: Não foi possível executar a declaração sql");
            }
        } catch (PDOException $erro) {
            echo "Erro: " . $erro->getMessage();
        }
    }
    /*link referencia - https://alexandrebbarbosa.wordpress.com/2016/09/04/php-pdo-crud-completo/comment-page-1/*/
?>