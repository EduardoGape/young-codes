<?php
  include_once '../Model/Config.php';

  $id = 5;
  $nome = "Novo nome do Ricardo";

  try {
    $stmt = $conn->prepare('UPDATE minhaTabela SET nome = :nome WHERE id = :id');
    $stmt->execute(array(
      ':id'   => $id,
      ':nome' => $nome
    ));

    echo $stmt->rowCount();
  } catch(PDOException $e) {
    echo 'Error: ' . $e->getMessage();
  }
?>