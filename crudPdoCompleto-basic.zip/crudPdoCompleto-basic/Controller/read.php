<?php
    include_once '../Model/Config.php';
    $consulta = $conn->query("SELECT nome FROM minhaTabela;");


    while ($linha = $consulta->fetch(PDO::FETCH_ASSOC)) {
        echo "Nome: {$linha['nome']}<br />";
    }
?>