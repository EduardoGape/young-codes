<?php
    include_once '../Model/Config.php';
    try {
        $stmt = $conn->prepare('INSERT INTO minhaTabela (nome) VALUES(:nome)');
        $stmt->execute(array(
            ':nome' => 'Ricardo Arrigoni'
        ));

        echo $stmt->rowCount();
    } catch(PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    }
?>